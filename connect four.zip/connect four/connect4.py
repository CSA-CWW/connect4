#cameron watts#
#comp prog#
#11 17 18#



############################################################
import tkinter
from tkinter import *
from tkinter import ttk
root = Tk()
root.attributes("-fullscreen", True)
def variables():
    global col_1, col_2, col_3, col_4, col_5, col_6, col_6, col_7, col_all, player, turn, brk, color
    col_1 = [None,None,None,None,None,None] 
    col_2 = [None,None,None,None,None,None]
    col_3 = [None,None,None,None,None,None]
    col_4 = [None,None,None,None,None,None]       #list of collumns, with row values inside#
    col_5 = [None,None,None,None,None,None]
    col_6 = [None,None,None,None,None,None]
    col_7 = [None,None,None,None,None,None]
    col_all = [col_1,col_2,col_3,col_4,col_5,col_6,col_7] #all the collumn lists combined#
    turn = 0 #turn counter#
    player = 'P1' ; color = 'FireBrick1' #standard starting player, and color#
    brk = 'idk' #break variable later used for disabling buttons#
############################################################
def bdisable():
    global cbutt
    for x in range(43):
        if x == 0:                               #button disable#
            pass
        else:
            cbutt[x].configure(state=DISABLED)  
#######################[MENU]###############################
def exitt(): #exits#
    quit()
###############
def restart(): #restarts#
    global cbutt, brk, turn
    brk = 'idk'
    variables()
    for x in range(43):         #restarts game#
        if x == 0:
            pass
        else:
            cbutt[x].configure(bg='SystemButtonFace', state=NORMAL)
    player = 'P1'
    turn = 1
    turnn()
###############
def about(): #about#
    top = Toplevel()
    top.title("About")

    msg = Message(top, text='CONNECT 4 \n\nFirst person to get 4 in arow wins. This can include vertical, horizontal, or diagonal combinations.')
    msg.pack()
    menubar = Menu(root)
###############
def menu(): #menu#
    menubar = Menu(root)

    filemenu = Menu(menubar, tearoff=0)
    filemenu.add_command(label="Restart", command=restart)
    filemenu.add_command(label="Exit", command=exitt)

    menubar.add_cascade(label="File", menu=filemenu)

    editmenu = Menu(menubar, tearoff=0)
    editmenu.add_command(label="About", command=about)

    menubar.add_cascade(label="Help", menu=editmenu)
    root.config(menu=menubar)
menu()
############################################################  
def turnn():       #turn function#
    global turn, color, player, turn_label,brk, winner
    if brk != 'end':
        turn += 1
        if turn % 2 == 0:
            player = 'P1'
        else:
            player = 'P2'
            
        if player == 'P1':
            color = 'FireBrick1'
        if player == 'P2':
            color = 'RoyalBlue3'
    else:
        player = winner
    turn_label.config(text='Turn> ' +str(player), bg=color, fg='White')
###################[WIN CHECK]#############################       
def win_check(): #combines all check functions into one#
    global countp1, countp2, winner         #variables that reset everytimethis function is run#
    countp1 = 0 ; countp2 = 0 ; winner = ''
############################          
    def vert_check():  #checks for forward combinations#
        global countp1, countp2, winner, x
        for x in range(7):
            for y in range(3):
                if col_all[x][y] == col_all[x][y+1] and col_all[x][y] != None:
                    if col_all[x][y+1] == col_all[x][y+2] and col_all[x][y+1] != None:
                        if col_all[x][y+2] == col_all[x][y+3] and col_all[x][y+2] != None:
                            if col_all[x][y+2] == 'P1':
                                countp1 = 4
                            if col_all[x][y+2] == 'P2':
                                countp2 = 4
                            f_check()
                        
############################
    def side_check(): #checks for sideways combinations#
        global countp1, countp2, winner, col_all, brk
        for x in range(6):
            if col_1[x] == col_2[x] and col_2[x] == col_3[x] and col_3[x] == col_4[x] and col_1[x] != None:
                if col_4[x] == 'P1':
                    countp1 = 4
                if col_4[x] == 'P2':
                    countp1 = 4    
                temp222()
            if col_2[x] == col_3[x] and col_3[x] == col_4[x] and col_4[x] == col_5[x] and col_2[x] != None:
                if col_5[x] == 'P1':
                    countp1 = 4
                if col_5[x] == 'P2':
                    countp1 = 4    
                temp222()
            if col_3[x] == col_4[x] and col_4[x] == col_5[x] and col_5[x] == col_6[x] and col_3[x] != None:
                if col_6[x] == 'P1':
                    countp1 = 4
                if col_6[x] == 'P2':
                    countp1 = 4    
                temp222()
            if col_4[x] == col_5[x] and col_5[x] == col_6[x] and col_6[x] == col_7[x] and col_4[x] != None:
                if col_7[x] == 'P1':
                    countp1 = 4
                if col_7[x] == 'P2':
                    countp1 = 4    
                f_check()
############################
    def f_check(): #checks if 4 in arow has been met.#
        global countp1, countp2, winner, brk, color
        if brk != 'end':
            if countp1 > 3:
                winner = 'Player 1 Wins'
                brk = 'end'
                color = 'FireBrick1'
                turn_label.config(text='Turn> ' +str(player), bg=color, fg='White')
            if countp2 > 3:
                winner = 'Player 2 Wins'
                brk = 'end'
                color = 'RoyalBlue2'
                turn_label.config(text='Turn> ' +str(player), bg=color, fg='White')
            else:
                countp1 = 0 ; countp2 = 0
        if brk == 'end':
            bdisable()
            turnn()
            turn = 'yemum'
#################                
    def di_check():        #checks diagonal combinations#
        global countp1, countp2, winner, col_all
        for c in range(7):
            for v in range(7):
                try:
                    if col_all[v+c][v] == col_all[v+1+c][v+1] and col_all[v+c][v] != None:
                        if col_all[v+1+c][v+1] == col_all[v+2+c][v+2] and col_all[v+1+c][v+1] != None:
                            if col_all[v+2+c][v+2] == col_all[v+3+c][v+3] and col_all[v+2+c][v+2] != None:
                                if col_all[v+c][v] == 'P1':
                                    countp1 = 4
                                if col_all[v+c][v] == 'P2':
                                    countp2 = 4
                except:
                    pass
                f_check()
            for v in range(7):
                try:
                    if col_all[v+c][-v-1] == col_all[v+1+c][-v-2] and col_all[v+c][-v-1] != None:
                        if col_all[v+1+c][-v-2] == col_all[v+2+c][-v-3] and col_all[v+1+c][-v-2] != None:
                            if col_all[v+2+c][-v-3] == col_all[v+3+c][-v-4] and col_all[v+2+c][-v-3] != None:
                                if col_all[v+c][-v-1] == 'P1':
                                    countp1 = 4
                                if col_all[v+c][-v-1] == 'P2':
                                    countp2 = 4
                except:
                    pass
                f_check()
            for v in range(7):
                try:
                    if col_all[v+c][-v-2] == col_all[v+1+c][-v-3] and col_all[v+c][-v-2] != None:
                        if col_all[v+1+c][-v-3] == col_all[v+2+c][-v-4] and col_all[v+1+c][-v-3] != None:
                            if col_all[v+2+c][-v-4] == col_all[v+3+c][-v-5] and col_all[v+2+c][-v-4] != None:
                                if col_all[v+c][-v-2] == 'P1':
                                    countp1 = 4
                                if col_all[v+c][-v-2] == 'P2':
                                    countp2 = 4
                except:
                    pass
                f_check()
            for v in range(7):
                try:
                    if col_all[v+c][v+1] == col_all[v+1+c][v+2] and col_all[v+c][v+1] != None:
                        if col_all[v+1+c][v+2] == col_all[v+2+c][v+3] and col_all[v+1+c][v+2] != None:
                            if col_all[v+2+c][v+3] == col_all[v+3+c][v+4] and col_all[v+2+c][v+3] != None:
                                if col_all[v+c][v+1] == 'P1':
                                    countp1 = 4
                                if col_all[v+c][v+1] == 'P2':
                                    countp2 = 4
                except:
                    pass
                f_check()
            for v in range(7):
                try:
                    if col_all[-v-c-1][-v-1] == col_all[-v-2-c][-v-2] and col_all[-v-c-1][-v-1] != None:
                        if col_all[-v-2-c][-v-2] == col_all[-v-3-c][-v-3] and col_all[-v-2-c][-v-2] != None:
                            if col_all[-v-3-c][-v-3] == col_all[-v-4-c][-v-4] and col_all[v-3-c][-v-3] != None:
                                if col_all[-v-c-1][-v-1] == 'P1':
                                    countp1 = 4
                                if col_all[-v-c-1][-v-1] == 'P2':
                                    countp2 = 4
                except:
                    pass
                f_check()
            for v in range(7):
                try:
                    if col_all[-v-c-1][-v-2] == col_all[-v-2-c][-v-3] and col_all[-v-c-1][-v-2] != None:
                        if col_all[-v-2-c][-v-3] == col_all[-v-3-c][-v-4] and col_all[-v-2-c][-v-3] != None:
                            if col_all[-v-3-c][-v-4] == col_all[-v-4-c][-v-5] and col_all[v-3-c][-v-4] != None:
                                if col_all[-v-c-1][-v-2] == 'P1':
                                    countp1 = 4
                                if col_all[-v-c-1][-v-2] == 'P2':
                                    countp2 = 4
                except:
                    pass
                f_check()
                
            for v in range(7):
                try:
                    if col_all[-v-c-1][v] == col_all[-v-2-c][v+1] and col_all[-v-c-1][v+1] != None:
                        if col_all[-v-2-c][v+2] == col_all[-v-3-c][v+3] and col_all[-v-2-c][v+2] != None:
                            if col_all[-v-3-c][v+3] == col_all[-v-4-c][v+4] and col_all[v-3-c][v+3] != None:
                                if col_all[-v-c-1][v] == 'P1':
                                    countp1 = 4
                                if col_all[-v-c-1][v] == 'P2':
                                    countp2 = 4
                except:
                    pass
                f_check()
            for v in range(7):
                try:
                    if col_all[-v-c-1][v+1] == col_all[-v-2-c][v+2] and col_all[-v-c-1][v+1] != None:
                        if col_all[-v-2-c][v+2] == col_all[-v-3-c][v+3] and col_all[-v-2-c][v+2] != None:
                            if col_all[-v-3-c][v+3] == col_all[-v-4-c][v+3] and col_all[v-3-c][v+3] != None:
                                if col_all[-v-c-1][v+1] == 'P1':
                                    countp1 = 4
                                if col_all[-v-c-1][v+1] == 'P2':
                                    countp2 = 4
                except:
                    pass
                f_check()
                
    vert_check()
    side_check()
    di_check()
###########################################################
def col_1check():
    global player, turn, cbutt, color,brk
    for x in range(7):
        y = x 
        if col_1[-y -1] == None:
            col_1[-y -1] = player
            break
    z = (6 - y)
    cbutt[z].configure(bg=color,state=DISABLED)                                                     #configures buttons in that collumn after being selected#
    turnn()
    if turn % 2 == 0:
        player = 'P1'
    else:
        player = 'P2'
        
    win_check()
###########################################################        
def col_2check():
    global player, turn, cbutt, color,brk        
    for x in range(7):
        y = x
        if col_2[-y -1] == None:
            col_2[-y -1] = player
            break
    z = (12 - y)
    cbutt[z].configure(bg=color,state=DISABLED)                                                     #configures buttons in that collumn after being selected#
    turnn()
    if turn % 2 == 0:
        player = 'P1'
    else:
        player = 'P2'
    win_check()
###########################################################        
def col_3check():
    global player, turn, cbutt, color,brk
    for x in range(7):
        y = x
        if col_3[-y -1] == None:
            col_3[-y -1] = player
            break
    z = (18 - y)
    cbutt[z].configure(bg=color,state=DISABLED)                                                     #configures buttons in that collumn after being selected#
    turnn()
    if turn % 2 == 0:
        player = 'P1'
    else:
        player = 'P2'
        
    win_check()
###########################################################    
def col_4check():
    global player, turn, cbutt, color,brk
    for x in range(7):
        y = x
        if col_4[-y -1] == None:
            col_4[-y -1] = player
            break
    z = (24 - y)
    cbutt[z].configure(bg=color,state=DISABLED)                                            #configures buttons in that collumn after being selected#
    turnn()
    if turn % 2 == 0:
        player = 'P1'
    else:
        player = 'P2'

    win_check()
###########################################################    
def col_5check():
    global player, turn, cbutt, color,brk        
    for x in range(7):
        y = x
        if col_5[-y -1] == None:
            col_5[-y -1] = player
            break
    z = (30 - y)
    cbutt[z].configure(bg=color,state=DISABLED)                                                        #configures buttons in that collumn after being selected#
    turnn()
    if turn % 2 == 0:
        player = 'P1'
    else:
        player = 'P2'

    win_check()
###########################################################    
def col_6check():
    global player, turn, cbutt, color,brk
    for x in range(7):
        y = x
        if col_6[-y -1] == None:
            col_6[-y -1] = player
            break
    z = (36 - y)
    cbutt[z].configure(bg=color,state=DISABLED)                                 #configures buttons in that collumn after being selected#
    turnn()
    if turn % 2 == 0:
        player = 'P1'
    else:
        player = 'P2'

    win_check()
###########################################################    
def col_7check():
    global player, turn, cbutt, color,brk
    for x in range(7):
        y = x
        if col_7[-y -1] == None:
            col_7[-y -1] = player
            break
    z = (42 - y)
    cbutt[z].configure(bg=color,state=DISABLED)                             #configures buttons in that collumn after being selected#
    turnn()
    if turn % 2 == 0:
        player = 'P1'
    else:
        player = 'P2'
        
    win_check()
###########################################################
def button_configure():
    global cbutt,rw,col, player, turn_label, color
    cbutt = {'temp':'...'}
    rw = 1 ; col = 1 
    for x in range(43):
        if x == 0:
            pass
        else:
            if 'temp' in cbutt:
                del cbutt['temp']
            
            if rw > 6:
                col += 1
                rw = 1
                
            cbutt[x] = Button(root,width=10,height=5,anchor="c", state=NORMAL)        #configures buttons at the start of the game#
            cbutt[x].grid(column=col,row=rw,sticky='NSEW')
            
            rw += 1
            
            if col == 1:
                cbutt[x].configure(command=col_1check)
            if col == 2:
                cbutt[x].configure(command=col_2check)
            if col == 3:
                cbutt[x].configure(command=col_3check)
            if col == 4:
                cbutt[x].configure(command=col_4check)
            if col == 5:
                cbutt[x].configure(command=col_5check)
            if col == 6:
                cbutt[x].configure(command=col_6check)
            if col == 7:
                cbutt[x].configure(command=col_7check)
###########################################################
def image_configure():
    global cbutt,rw,col, player, turn_label, color
    imag = PhotoImage(file="connect4image.png")
    label = Label(root, image=imag)
    label.image = imag
    label.grid(column=3,row=0,columnspan=3)

    turn_label = Label(text='Turn> ' +str(player), bg=color, fg='White')       #configures image and label#
    turn_label.config(width=20,font=("Arial", 14))
    turn_label.grid(column=1,row=7,columnspan=7)
    blank_label = Label(root, text='', height=0, width=67)
    blank_label.grid(column=0,row=0)
    
variables()       
button_configure()
image_configure()
